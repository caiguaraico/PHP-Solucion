﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;
using EL;

namespace BL
{
    public class SucursalBL
    {
        private SucursalDL sucursalDL = new SucursalDL();

        public List<Sucursal> Listar()
        {
            return sucursalDL.Listar();
        }

        public List<Sucursal> ListarPorBanco(int id)
        {
            return sucursalDL.ListarPorBanco(id);
        }

        public Sucursal Obtener(int id)
        {
            return sucursalDL.Obtener(id);
        }

        public bool Actualizar(Sucursal sucursal)
        {
            return sucursalDL.Actualizar(sucursal);
        }

        public bool Registrar(Sucursal sucursal)
        {
            return sucursalDL.Registrar(sucursal);
        }

        public bool Eliminar(int id)
        {
            return sucursalDL.Eliminar(id);
        }
    }
}
