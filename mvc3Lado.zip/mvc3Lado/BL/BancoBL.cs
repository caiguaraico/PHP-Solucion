﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;
using EL;

namespace BL
{
    public class BancoBL
    {
        private BancoDL bancoDL = new BancoDL();

        public List<Banco> Listar()
        {
            return bancoDL.Listar();
        }

        public Banco Obtener(int id)
        {
            return bancoDL.Obtener(id);
        }

        public bool Actualizar(Banco banco)
        {
            return bancoDL.Actualizar(banco);
        }

        public bool Registrar(Banco banco)
        {
            return bancoDL.Registrar(banco);
        }

        public bool Eliminar(int id)
        {
            return bancoDL.Eliminar(id);
        }
    }
}
