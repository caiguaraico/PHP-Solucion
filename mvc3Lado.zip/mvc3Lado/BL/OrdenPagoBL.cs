﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DL;
using EL;

namespace BL
{
    public class OrdenPagoBL
    {
        private OrdenPagoDL ordenpagoDL = new OrdenPagoDL();

        public List<OrdenPago> Listar()
        {
            return ordenpagoDL.Listar();
        }

        public List<OrdenPago> ListarPorSucursal(int id)
        {
            return ordenpagoDL.ListarPorSucursal(id);
        }

        public OrdenPago Obtener(int id)
        {
            return ordenpagoDL.Obtener(id);
        }

        public bool Actualizar(OrdenPago ordenpago)
        {
            return ordenpagoDL.Actualizar(ordenpago);
        }

        public bool Registrar(OrdenPago ordenpago)
        {
            return ordenpagoDL.Registrar(ordenpago);
        }

        public bool Eliminar(int id)
        {
            return ordenpagoDL.Eliminar(id);
        }
    }
}
