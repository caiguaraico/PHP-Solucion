﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppParte01
{
    class MoneyParts
    {
        #region [MoneyParts]

        public void build(string textoEntrada)
        {

            Decimal[] denominacionesEntrada = { (Decimal)0.05, (Decimal)0.1, (Decimal)0.2, (Decimal)0.5, 1, 2, 5, 10, 20, 50, 100, 200 };
            List<Decimal> denominacionesSalida = new List<Decimal>();
            Decimal montoEntrada = Convert.ToDecimal(textoEntrada);
            Decimal montoTemp = 0;
            Decimal divisionTemp = 0;

            List<string> listaCombinaciones = new List<string>();
            string textoAcumulativoSecuencial = "";
            string textoAcumulativoIntercalado = "";
            Decimal sumaSecuencial = 0;
            Decimal sumaIntercalado = 0;


            for (int i = 0; i < denominacionesEntrada.Length; i++)
            {
                montoTemp = denominacionesEntrada[i];
                divisionTemp = Math.Truncate(montoEntrada / montoTemp);

                if (montoTemp < montoEntrada)
                {
                    for (int index = 0; index < divisionTemp; index++)
                    {
                        denominacionesSalida.Add(montoTemp);
                    }
                }
            }


            for (int a = 0; a < denominacionesSalida.Count; a++)
            {
                textoAcumulativoSecuencial = "[ ";
                sumaSecuencial = 0;

                for (int b = a; b < denominacionesSalida.Count; a++)
                {
                    if (textoAcumulativoSecuencial == "[ ")
                        textoAcumulativoSecuencial += denominacionesSalida[b];
                    else
                        textoAcumulativoSecuencial += ", " + denominacionesSalida[b];

                    sumaSecuencial += denominacionesSalida[b];

                    if (sumaSecuencial >= montoEntrada)
                    {
                        if (sumaSecuencial == montoEntrada)
                            listaCombinaciones.Add(textoAcumulativoSecuencial + " ]");

                        continue;
                    }


                    for (int c = b; c < denominacionesSalida.Count; c++)
                    {
                        textoAcumulativoIntercalado = string.Empty;
                        textoAcumulativoIntercalado = textoAcumulativoSecuencial;
                        sumaIntercalado = sumaSecuencial;

                        for (int d = c + 1; d < denominacionesSalida.Count - 1; d++)
                        {
                            if (textoAcumulativoIntercalado == "[ " + textoAcumulativoSecuencial)
                                textoAcumulativoIntercalado += denominacionesSalida[d + 1];
                            else
                                textoAcumulativoIntercalado += ", " + denominacionesSalida[d + 1];

                            sumaIntercalado += denominacionesSalida[d + 1];

                            if (sumaIntercalado >= montoEntrada)
                            {
                                if (sumaIntercalado == montoEntrada)
                                    listaCombinaciones.Add(textoAcumulativoIntercalado + " ]");
                            
                                continue;
                            }
                        }

                        if (sumaIntercalado > montoEntrada)
                            continue;
                    }
                }
            }


            List<String> listaSinDuplicados = (from w in listaCombinaciones select w).Distinct().ToList();
            listaSinDuplicados.Sort();



            Console.WriteLine("");
            Console.WriteLine("El monto a evaluar es: " + textoEntrada);
            Console.WriteLine("");
            Console.Write("lista de monedas : ");
            denominacionesSalida.ForEach(itemX => Console.Write(itemX + ", "));
            Console.WriteLine("");
            Console.WriteLine("");
            Console.Write("Final :  [");
            listaSinDuplicados.ForEach(itemX => Console.Write(itemX + ", "));
            Console.WriteLine(" ]");
            Console.WriteLine("");
        }

        #endregion
    }
}
