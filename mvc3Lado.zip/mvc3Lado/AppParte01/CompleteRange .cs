﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppParte01
{
    class CompleteRange
    {

        public void build(int[] listaNumerosEntrada)
        {

            Array.Sort(listaNumerosEntrada);
            Array.Reverse(listaNumerosEntrada);

            int[] listaNumerosFinal = new int[listaNumerosEntrada[0]];

            for (int i = 0; i < listaNumerosEntrada[0]; i++)
            {
                listaNumerosFinal[i] = i + 1;
            }

            Console.WriteLine("El arreglo entrada es: ");
            Console.WriteLine(string.Join(",", listaNumerosEntrada));
            Console.WriteLine("El numero menor es: " + listaNumerosEntrada.Min());
            Console.WriteLine("El numero mayor es: " + listaNumerosEntrada.Max());
            Console.WriteLine("El arreglo final es: ");
            Console.WriteLine(string.Join(",", listaNumerosFinal));
            Console.WriteLine();

        }

    }
}
