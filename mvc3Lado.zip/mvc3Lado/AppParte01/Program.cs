﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppParte01
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numeros1 = { 2, 1, 4, 5 };
            int[] numeros2 = { 4, 2, 9 };
            int[] numeros3 = { 58, 60, 55 };


            ChangeString changeString = new ChangeString();
            CompleteRange completeRante = new CompleteRange();
            MoneyParts moneyParts = new MoneyParts();


            changeString.build("123 abcd*3");
            changeString.build("**Casa 52");


            completeRante.build(numeros1);
            completeRante.build(numeros2);
            completeRante.build(numeros3);

            moneyParts.build("0.1");
            moneyParts.build("0.5");
            moneyParts.build("10.50");



            Console.WriteLine("");
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
