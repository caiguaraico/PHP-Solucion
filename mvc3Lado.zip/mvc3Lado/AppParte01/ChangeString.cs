﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppParte01
{
    class ChangeString
    {

        public void build(string textoEntrada)
        {

            string[] abecedarioEntrada = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "w", "x", "y", "z" };
            string abecederaioTemp = "";
            string abecederaioFinal = "";
            string textoFinal = "";
            int posicionLetra = 0;


            for (int i = 0; i < abecedarioEntrada.Length; i++)
            {
                abecederaioFinal += abecedarioEntrada[i];
                abecederaioTemp += abecedarioEntrada[i].ToUpper();
            }

            abecederaioFinal += abecederaioFinal[abecederaioTemp.Length - 1] + abecederaioTemp + abecederaioTemp[abecederaioTemp.Length - 1];

            for (int i = 0; i < textoEntrada.Length; i++)
            {
                posicionLetra = abecederaioFinal.IndexOf(textoEntrada[i]);

                if (posicionLetra >= 0)
                {
                    textoFinal += abecederaioFinal[posicionLetra + 1];
                }
                else
                {
                    textoFinal += textoEntrada[i];
                }
            }

            Console.WriteLine(abecedarioEntrada.Length);
            Console.WriteLine(abecederaioFinal);
            Console.WriteLine(textoEntrada);
            Console.WriteLine(textoFinal);

        }

    }
}
