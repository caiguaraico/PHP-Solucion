﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BL;
using EL;
using System.Web.Mvc;

namespace mvc3Lado.Controllers
{
    public class SucursalServicesController : ApiController
    {
        private SucursalBL sucursalBL = new SucursalBL();

        // GET: ALL Sucursal
        public HttpResponseMessage GetAllSucursalServices()
        {
            return Request.CreateResponse(HttpStatusCode.OK, sucursalBL.Listar());
        }


        // GET api/sucursal/1
        public HttpResponseMessage GetSucursalServices(int id)
        {
            List<Sucursal> sucursal = sucursalBL.ListarPorBanco(id);
            if (sucursal == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return Request.CreateResponse(HttpStatusCode.OK, sucursal); ;
        }
    }
}
