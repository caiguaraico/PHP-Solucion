﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BL;
using EL;


namespace mvc3Lado.Controllers
{
    public class OrdenPagoController : Controller
    {
        //
        // GET: /OrdenPago/

        private OrdenPagoBL OrdenPagoBL = new OrdenPagoBL();
        private SucursalBL sucursalBL = new SucursalBL();
        private BancoBL bancoBL = new BancoBL();
        private Sucursal sucursal = new Sucursal();
        private OrdenPago ordenpago = new OrdenPago();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>

        public ActionResult Index(int id)
        {
            sucursal = sucursalBL.Obtener(id);
            ViewBag.Sucursal = sucursal;
            ViewBag.Banco = bancoBL.Obtener(sucursal.banco_id);

            return View(OrdenPagoBL.ListarPorSucursal(id));
        }

        public ActionResult Nuevo(int id)
        {
            sucursal = sucursalBL.Obtener(id);

            ViewBag.Sucursal = sucursal;
            ViewBag.Banco = bancoBL.Obtener(sucursal.banco_id);

            return View(id == 0 ? new OrdenPago() : OrdenPagoBL.Obtener(id));
        }

        public ActionResult Editar(int id = 0)
        {
            ordenpago = OrdenPagoBL.Obtener(id);
            sucursal = sucursalBL.Obtener(ordenpago.sucursal_id);

            ViewBag.Sucursal = sucursal;
            ViewBag.Banco = bancoBL.Obtener(sucursal.banco_id);

            return View(id == 0 ? new OrdenPago() : OrdenPagoBL.Obtener(id));
        }

        public ActionResult Guardar(OrdenPago ordenpago)
        {
            var r = ordenpago.ordenpago_id > 0 ?
                    OrdenPagoBL.Actualizar(ordenpago) :
                    OrdenPagoBL.Registrar(ordenpago);

            if (!r)
            {
                // Podemos validar para mostrar un mensaje personalizado, por ahora el aplicativo se caera por el throw que hay en nuestra capa DAL
                ViewBag.Mensaje = "Ocurrio un error inesperado";
                return View("~/Views/Shared/_Mensajes.cshtml");
            }

            return Redirect("~/ordenpago/index/" + ordenpago.sucursal_id);
        }

        public ActionResult Eliminar(int id)
        {
            ordenpago = OrdenPagoBL.Obtener(id);

            var r = OrdenPagoBL.Eliminar(id);

            if (!r)
            {
                // Podemos validar para mostrar un mensaje personalizado, por ahora el aplicativo se caera por el throw que hay en nuestra capa DAL
                ViewBag.Mensaje = "Ocurrio un error inesperado";
                return View("~/Views/Shared/_Mensajes.cshtml");
            }

            return Redirect("~/ordenpago/index/" + ordenpago.sucursal_id);
        }

    }
}
