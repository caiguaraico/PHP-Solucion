﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BL;
using EL;

namespace mvc3Lado.Controllers
{
    public class BancoController : Controller
    {
        //
        // GET: /Banco/


        private BancoBL BancoBL = new BancoBL();
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //private RolBL rolBL = new RolBL();

        public ActionResult Index()
        {
            return View(BancoBL.Listar());
        }

        public ActionResult Editar(int id = 0)
        {
            //ViewBag.Roles = rolBL.Listar();
            return View(id == 0 ? new Banco() : BancoBL.Obtener(id));
        }

        public ActionResult Guardar(Banco banco)
        {
            var r = banco.banco_id > 0 ?
                    BancoBL.Actualizar(banco) :
                    BancoBL.Registrar(banco);

            if (!r)
            {
                // Podemos validar para mostrar un mensaje personalizado, por ahora el aplicativo se caera por el throw que hay en nuestra capa DAL
                ViewBag.Mensaje = "Ocurrio un error inesperado";
                return View("~/Views/Shared/_Mensajes.cshtml");
            }

            return Redirect("~/");
        }

        public ActionResult Eliminar(int id)
        {
            var r = BancoBL.Eliminar(id);

            if (!r)
            {
                // Podemos validar para mostrar un mensaje personalizado, por ahora el aplicativo se caera por el throw que hay en nuestra capa DAL
                ViewBag.Mensaje = "Ocurrio un error inesperado";
                return View("~/Views/Shared/_Mensajes.cshtml");
            }

            return Redirect("~/");
        }



    }
}
