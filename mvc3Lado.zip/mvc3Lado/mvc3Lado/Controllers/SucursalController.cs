﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BL;
using EL;


namespace mvc3Lado.Controllers
{
    public class SucursalController : Controller
    {
        //
        // GET: /Sucursal/

        private SucursalBL SucursalBL = new SucursalBL();
        private BancoBL bancoBL = new BancoBL();
        private Sucursal sucursal = new Sucursal();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //private RolBL rolBL = new RolBL();

        public ActionResult Index(int id)
        {
            ViewBag.Banco = bancoBL.Obtener(id);
            return View(SucursalBL.ListarPorBanco(id));
        }

        public ActionResult Nuevo(int id)
        {
            ViewBag.Banco = bancoBL.Obtener(id);
            return View(new Sucursal());
        }

        public ActionResult Editar(int id = 0)
        {
            sucursal = SucursalBL.Obtener(id);
            ViewBag.Banco = bancoBL.Obtener(sucursal.banco_id);

            return View(id == 0 ? new Sucursal() : SucursalBL.Obtener(id));
        }

        public ActionResult Guardar(Sucursal sucursal) //, Banco banco)
        {
            var r = sucursal.sucursal_id > 0 ?
                    SucursalBL.Actualizar(sucursal) :
                    SucursalBL.Registrar(sucursal);

            if (!r)
            {
                // Podemos validar para mostrar un mensaje personalizado, por ahora el aplicativo se caera por el throw que hay en nuestra capa DAL
                ViewBag.Mensaje = "Ocurrio un error inesperado";
                return View("~/Views/Shared/_Mensajes.cshtml");
            }

            return Redirect("~/sucursal/index/" + sucursal.banco_id);
        }

        public ActionResult Eliminar(int id)
        {
            sucursal = SucursalBL.Obtener(id);
            var r = SucursalBL.Eliminar(id);

            if (!r)
            {
                // Podemos validar para mostrar un mensaje personalizado, por ahora el aplicativo se caera por el throw que hay en nuestra capa DAL
                ViewBag.Mensaje = "Ocurrio un error inesperado";
                return View("~/Views/Shared/_Mensajes.cshtml");
            }

            return Redirect("~/sucursal/index/" +  sucursal.banco_id);
        }

    }
}
