﻿using System.Web.Mvc;

namespace mvc3Lado.Areas.ApiJson
{
    public class ApiJsonAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "ApiJson";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Api_OrdenPagoJson",
                "ApiJson/OrdenPagoJson",
                new { controller = "OrdenPagoJson", action = "OrdenPagoJson" }
            );
            context.MapRoute(
                "Api_OrdenJson",
                "ApiJson/OrdenPagoJson/OrdenJson/{id}",
                new { controller = "OrdenPagoJson", action = "Orden", id = UrlParameter.Optional }
            );
            context.MapRoute(
                "Api_BancosJson",
                "ApiJson/BancosJson",
                new { controller = "BancosJson", action = "BancosJson" }
            );
            context.MapRoute(
                "Api_BancoJson",
                "ApiJson/BancosJson/BancosJson/{id}",
                new { controller = "BancosJson", action = "Banco", id = UrlParameter.Optional }
            );
            context.MapRoute(
                "ApiJson_default",
                "ApiJson/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
