﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using BL;
using EL;
using System.Web;
using System.Web.Mvc;


namespace mvc3Lado.Areas.ApiJson.Controllers
{
    public class OrdenPagoJsonController : Controller
    {

        private OrdenPagoBL ordenpagoBL;

        public OrdenPagoJsonController()
        {
            ordenpagoBL = new OrdenPagoBL();
        }


        // GET /Api/OrdenPagoJson
        [HttpGet]

        public JsonResult OrdenPagoJson()
        {
            return Json(ordenpagoBL.Listar(), JsonRequestBehavior.AllowGet);
        }


        public JsonResult Orden(int? id, OrdenPago ordenpago)
        {
            switch (Request.HttpMethod)
            {
                case "POST":
                    // true or false
                    return Json(ordenpagoBL.Registrar(ordenpago));
                case "PUT":
                    // true or false
                    return Json(ordenpagoBL.Registrar(ordenpago));
                case "GET":
                    // Obtendremos por sucursal
                    return Json(ordenpagoBL.ListarPorSucursal(id.GetValueOrDefault()), JsonRequestBehavior.AllowGet);
                case "DELETE":
                    // true or false
                    return Json(ordenpagoBL.Eliminar(id.GetValueOrDefault()));
            }

            return Json(new { Error = true, Message = "Operación HTTP desconocida" });
        }

    }
}
