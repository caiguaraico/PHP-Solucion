﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EL
{
    public class Sucursal
    {
        public int sucursal_id { get; set; }
        public string nombre { get; set; }
        public string direccion { get; set; }
        public int banco_id { get; set; }

        ////////public Banco Banco { get; set; }

        ////////public Sucursal() 
        ////////{
        ////////    Banco = new Banco();
        ////////}

    }
}
