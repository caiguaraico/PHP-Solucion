﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EL
{
    public class OrdenPago
    {
        public int ordenpago_id { get; set; }
        public Decimal monto { get; set; }
        public string moneda { get; set; }
        public string estado { get; set; }
        public DateTime fechapago { get; set; }
        public int sucursal_id { get; set; }
    }
}
