﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EL;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;


namespace DL
{
    public class SucursalDL
    {

        public List<Sucursal> Listar()
        {
            var sucursal = new List<Sucursal>();

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("SELECT * FROM Sucursales", con);

                    using (var dr = query.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var Sucursal = new Sucursal
                            {
                                sucursal_id = Convert.ToInt32(dr["sucursal_id"]),
                                nombre = dr["nombre"].ToString(),
                                direccion = dr["direccion"].ToString(),
                                banco_id = Convert.ToInt32(dr["banco_id"]),
                            };

                            sucursal.Add(Sucursal);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return sucursal;
        }

        public List<Sucursal> ListarPorBanco(int id)
        {
            var sucursal = new List<Sucursal>();

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("SELECT * FROM Sucursales WHERE banco_id = @id", con);
                    query.Parameters.AddWithValue("@id", id);

                    using (var dr = query.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var Sucursal = new Sucursal
                            {
                                sucursal_id = Convert.ToInt32(dr["sucursal_id"]),
                                nombre = dr["nombre"].ToString(),
                                direccion = dr["direccion"].ToString(),
                                banco_id = Convert.ToInt32(dr["banco_id"]),
                            };

                            sucursal.Add(Sucursal);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return sucursal;
        }

        public Sucursal Obtener(int id)
        {
            var sucursal = new Sucursal();

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("SELECT * FROM Sucursales WHERE sucursal_id = @id", con);
                    query.Parameters.AddWithValue("@id", id);

                    using (var dr = query.ExecuteReader())
                    {
                        dr.Read();
                        if (dr.HasRows)
                        {
                            sucursal.sucursal_id = Convert.ToInt32(dr["sucursal_id"]);
                            sucursal.nombre = dr["nombre"].ToString();
                            sucursal.direccion = dr["direccion"].ToString();
                            sucursal.banco_id = Convert.ToInt32(dr["banco_id"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return sucursal;
        }

        public bool Actualizar(Sucursal sucursal)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("UPDATE Sucursales SET nombre = @p0, direccion = @p1, banco_id = @p2 WHERE sucursal_id = @p3", con);

                    query.Parameters.AddWithValue("@p0", sucursal.nombre);
                    query.Parameters.AddWithValue("@p1", sucursal.direccion);
                    query.Parameters.AddWithValue("@p2", sucursal.banco_id);
                    query.Parameters.AddWithValue("@p3", sucursal.sucursal_id);

                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

        public bool Registrar(Sucursal sucursal)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("INSERT INTO Sucursales(nombre, direccion, banco_id) VALUES (@p0, @p1, @p2)", con);

                    query.Parameters.AddWithValue("@p0", sucursal.nombre);
                    query.Parameters.AddWithValue("@p1", sucursal.direccion);
                    query.Parameters.AddWithValue("@p2", sucursal.banco_id);

                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

        public bool Eliminar(int id)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("DELETE FROM Sucursales WHERE sucursal_id = @p0", con);
                    query.Parameters.AddWithValue("@p0", id);
                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

    }
}
