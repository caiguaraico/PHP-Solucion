﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EL;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;


namespace DL
{
    public class BancoDL
    {

        public List<Banco> Listar()
        {
            var bancos = new List<Banco>();

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("SELECT * FROM Bancos", con);
                    using (var dr = query.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var Banco = new Banco
                            {
                                banco_id = Convert.ToInt32(dr["banco_id"]),
                                nombre = dr["nombre"].ToString(),
                                direccion  = dr["direccion"].ToString(),
                                fecharegistro = Convert.ToDateTime(dr["fecharegistro"].ToString()),
                            };

                            bancos.Add(Banco);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return bancos;
        }

        public Banco Obtener(int id)
        {
            var banco = new Banco();

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("SELECT * FROM Bancos WHERE banco_id = @id", con);
                    query.Parameters.AddWithValue("@id", id);

                    using (var dr = query.ExecuteReader())
                    {
                        dr.Read();
                        if (dr.HasRows)
                        {
                            banco.banco_id = Convert.ToInt32(dr["banco_id"]);
                            banco.nombre = dr["nombre"].ToString();
                            banco.direccion = dr["direccion"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return banco;
        }

        public bool Actualizar(Banco banco)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("UPDATE Bancos SET nombre = @p0, direccion = @p1 WHERE banco_id = @p2", con);

                    query.Parameters.AddWithValue("@p0", banco.nombre);
                    query.Parameters.AddWithValue("@p1", banco.direccion);
                    query.Parameters.AddWithValue("@p2", banco.banco_id);

                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

        public bool Registrar(Banco banco)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("INSERT INTO Bancos(nombre, direccion, fecharegistro) VALUES (@p0, @p1, getdate())", con);

                    query.Parameters.AddWithValue("@p0", banco.nombre);
                    query.Parameters.AddWithValue("@p1", banco.direccion);

                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

        public bool Eliminar(int id)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("DELETE FROM Bancos WHERE banco_id = @p0", con);
                    query.Parameters.AddWithValue("@p0", id);
                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

    }
}
