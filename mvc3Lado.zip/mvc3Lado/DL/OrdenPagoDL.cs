﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EL;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;

namespace DL
{
    public class OrdenPagoDL
    {

        public List<OrdenPago> Listar()
        {
            var OrdenPago = new List<OrdenPago>();

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("SELECT * FROM OrdenesPago", con);

                    using (var dr = query.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var ordenpago = new OrdenPago
                            {
                                ordenpago_id = Convert.ToInt32(dr["ordenpago_id"]),
                                monto = Convert.ToDecimal(dr["monto"].ToString()),
                                moneda = dr["moneda"].ToString(),
                                estado = dr["estado"].ToString(),
                                fechapago = Convert.ToDateTime(dr["fechapago"].ToString()),
                                sucursal_id = Convert.ToInt32(dr["sucursal_id"]),
                            };

                            OrdenPago.Add(ordenpago);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return OrdenPago;
        }

        public List<OrdenPago> ListarPorSucursal(int id)
        {
            var OrdenPago = new List<OrdenPago>();

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("SELECT * FROM OrdenesPago WHERE sucursal_id = @id", con);
                    query.Parameters.AddWithValue("@id", id);

                    using (var dr = query.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            var ordenpago = new OrdenPago
                            {
                                ordenpago_id = Convert.ToInt32(dr["ordenpago_id"]),
                                monto = Convert.ToDecimal(dr["monto"].ToString()),
                                moneda = dr["moneda"].ToString(),
                                estado = dr["estado"].ToString(),
                                fechapago = Convert.ToDateTime(dr["fechapago"].ToString()),
                                sucursal_id = Convert.ToInt32(dr["sucursal_id"]),
                            };

                            OrdenPago.Add(ordenpago);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return OrdenPago;
        }

        public OrdenPago Obtener(int id)
        {
            var ordenpago = new OrdenPago();

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("SELECT * FROM OrdenesPago WHERE ordenpago_id = @id", con);
                    query.Parameters.AddWithValue("@id", id);

                    using (var dr = query.ExecuteReader())
                    {
                        dr.Read();
                        if (dr.HasRows)
                        {
                            ordenpago.ordenpago_id = Convert.ToInt32(dr["ordenpago_id"]);
                            ordenpago.monto = Convert.ToDecimal(dr["monto"].ToString());
                            ordenpago.moneda = dr["moneda"].ToString();
                            ordenpago.estado = dr["estado"].ToString();
                            ordenpago.fechapago = Convert.ToDateTime(dr["fechapago"].ToString());
                            ordenpago.sucursal_id = Convert.ToInt32(dr["sucursal_id"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ordenpago;
        }

        public bool Actualizar(OrdenPago ordenpago)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("UPDATE OrdenesPago SET monto = @p0, moneda = @p1, estado = @p2, fechapago = @p3, sucursal_id = @p4 WHERE ordenpago_id = @p5", con);

                    query.Parameters.AddWithValue("@p0", ordenpago.monto);
                    query.Parameters.AddWithValue("@p1", ordenpago.moneda);
                    query.Parameters.AddWithValue("@p2", ordenpago.estado);
                    query.Parameters.AddWithValue("@p3", ordenpago.fechapago);
                    query.Parameters.AddWithValue("@p4", ordenpago.sucursal_id);
                    query.Parameters.AddWithValue("@p5", ordenpago.ordenpago_id);

                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

        public bool Registrar(OrdenPago ordenpago)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("INSERT INTO OrdenesPago (monto, moneda, estado, fechapago, sucursal_id) VALUES (@p0, @p1, @p2, @p3, @p4)", con);

                    query.Parameters.AddWithValue("@p0", ordenpago.monto);
                    query.Parameters.AddWithValue("@p1", ordenpago.moneda);
                    query.Parameters.AddWithValue("@p2", ordenpago.estado);
                    query.Parameters.AddWithValue("@p3", ordenpago.fechapago);
                    query.Parameters.AddWithValue("@p4", ordenpago.sucursal_id);

                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

        public bool Eliminar(int id)
        {
            bool respuesta = false;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Bancos"].ToString()))
                {
                    con.Open();

                    var query = new SqlCommand("DELETE FROM OrdenesPago WHERE ordenpago_id = @p0", con);
                    query.Parameters.AddWithValue("@p0", id);
                    query.ExecuteNonQuery();

                    respuesta = true;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return respuesta;
        }

    }
}
